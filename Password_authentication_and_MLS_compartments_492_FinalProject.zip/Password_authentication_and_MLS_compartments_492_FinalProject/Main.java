import java.util.*;
import java.io.*;  
import java.io.IOException; 
import java.security.*;
/**
 * 
 */
public class Main {
    private String profile;
    private static String[] userCredentials;
    private static String modeltype;

    /**
     * returns biba or blp model 
     */
    public static String getmodel(){        
        return modeltype;
    }

    /**
     * sets biba or blp model
     */
    public void setmodel(String model){
        this.modeltype = model;
    }   

    /**
     * returns user Credentials [FirstName,LastName,UserName,Password,SecurityLevel,Compartment]
     */
    public static String[] getcredentials(){
        return userCredentials;
    }

    /**
     * sets user credentials [FirstName,LastName,UserName,Password,SecurityLevel,Compartment]
     */
    public void setcredentials(String[] usercred){
        this.userCredentials = usercred;
    }

    /**
     * returns user credentials for user input purpose
     */
    public static void pcred(){
        getcredentials();    
    }

    /**
     * returns user credentials [FirstName,LastName,UserName,Password,SecurityLevel,Compartment] from users file
     */
    public String getProfile(){
        return profile;
    }

    /**
     * sets user credentials [FirstName,LastName,UserName,Password,SecurityLevel,Compartment] from users file
     */
    public void setProfile(String userprofile){
        this.profile = userprofile;
    }

    /**
     * Checks file and user comparment and validates if it is appropiate to open
     * Validates Comparment and checks if it is ok to open the file based off of the compartment of the file name and users credientials 
     */
    public static boolean validSecCom(String filename){
        Main obj = new Main();
        String[] SecurityLevels= {"unclassified","classified","secret","topsecret"};
        String[] Compartments={"A","B","AB"};        
        String[] temp = obj.getcredentials();
        int Compartment_level = 0;
        int foundCompartment = 0;
        int tttemp = temp.length;
        String[] arrOfStr = filename.split("_");
        for (String a : arrOfStr){
            for (int i=0; i < Compartments.length; i++){
                if(a.equals(Compartments[i]))
                {
                    foundCompartment++;
                    Compartment_level = i;                    
                }
            }
        }

        if(foundCompartment == 0){
            return true;                
        }else if (foundCompartment > 0 && tttemp == 5){
            return false;
        }else if(foundCompartment > 0 && !Compartments[Compartment_level].equals(temp[5])){
            if(temp[5].equals("AB")){
                return true;
            }else{
                return false;        
            }
        }else if (foundCompartment > 0 && Compartments[Compartment_level].equals(temp[5])){
            return true;
        }else{
            return false;                
        }

    }

    /**
     * Checks file Security and user security
     * Write Checks the model type biba or blp Types and the rules for that model and writes text to file if it is appropriate. 
     */
    public static void write(String[] var){
        int inlength = var.length;
        Main obj = new Main();

        if (inlength < 2){
            System.out.print("Please try again and indicate the file you wish to read");
        }else if(obj.getmodel() == null){
            System.out.print("Please log in first");
        }else if(obj.getmodel().equals("biba simple")){
            boolean openornot = bibamodel(var);
            if (openornot == true){
                openwrite(var);
            }
        }else if(obj.getmodel().equals("biba star")){
            boolean openornot = bibamodel(var);
            if (openornot == true){
                openwrite(var);
            }
        }else if(obj.getmodel().equals("biba strongstar")){
            boolean openornot = bibamodel(var);
            if (openornot == true){
                openwrite(var);
            }
        }else if(obj.getmodel().equals("blp simple")){
            boolean openornot = blpmodel(var);
            if (openornot == true){
                openwrite(var);
            }
        }else if(obj.getmodel().equals("blp star")){
            boolean openornot = blpmodel(var);
            if (openornot == true){
                openwrite(var);
            }
        }else if(obj.getmodel().equals("blp strongstar")){
            boolean openornot = blpmodel(var);
            if (openornot == true){
                openwrite(var);
            }
        }else{
            System.out.print("Error Something went wrong");
        }
    }

    /**
     * Checks file Security and user security and comparment
     * Checks if read or write was input and blp model types and returns true or false if it is appropriate to read or write file
     */
    public static boolean blpmodel(String[] var){
        Main obj = new Main();
        String modelType= obj.getmodel();
        String[] SecurityLevels= {"unclassified","classified","secret","topsecret"};
        String filename = var[1];
        boolean tempchar = filename.contains("_");        
        int found = 0;
        int found1 = 0;
        int filesecurity_level = 0;
        int mysecurity_level = 0;
        boolean compar = obj.validSecCom(filename);

        System.out.println(filename);
        if (tempchar == true){
            if (compar == true){
                String[] arrOfStr = filename.split("_");
                for (String a : arrOfStr){
                    for (int i=0; i < SecurityLevels.length; i++){
                        if(a.equals(SecurityLevels[i]))
                        {
                            found++;
                            filesecurity_level =i;
                            break;
                        }
                    }
                }

                for (int i=0; i < SecurityLevels.length; i++){
                    String[] temp = obj.getcredentials(); 
                    if(temp[4].equals(SecurityLevels[i]))
                    {
                        found1++;
                        mysecurity_level =i;
                    }
                }

                if (found1 > 0 && found > 0 ){
                    if (modelType.equals("blp simple")){

                        if (filesecurity_level <= mysecurity_level && var[0].equals("read")){
                            return true;
                        }else if (modelType.equals("blp simple") && var[0].equals("write")){
                            System.out.println("You can't write with the simple confidenttiality rule");
                            return false;
                        }else{
                            System.out.print("File is out of your security clerence");                          
                            return false;
                        } 
                    }else if (modelType.equals("blp strongstar")){

                        if (filesecurity_level == mysecurity_level && var[0].equals("read")){
                            return true;
                        }else if (filesecurity_level == mysecurity_level && var[0].equals("write")){
                            return true;
                        }else{
                            System.out.println("File is out of your security clerence");                            
                            return false;
                        }         

                    }else if (modelType.equals("blp star")){

                        if(modelType.equals("blp star") && var[0].equals("read")){
                            System.out.println("Access denied you cant read files with the star confidenttiality rule");
                            System.out.println("You can only write files at or above your security level");
                            return false;
                        }else if(filesecurity_level >= mysecurity_level && var[0].equals("write")){
                            return true;
                        }else{
                            System.out.println("File is out of your security clerence");
                            return false;
                        } 
                    }

                }else{
                    System.out.println("Security level not found");
                    System.out.println("No security level or improper format of file name.");
                    return false;
                } 

            }else{
                System.out.println("File is out of your security clerence");
                System.out.println("File compartment out of clerence");
                return false; 
            }
        }else{
            System.out.println("File has no security level or the file name format is incorrect! ");
            return false;
        }
        return false;
    }

    /**
     * Checks file Security and user security and comparment
     * Checks if read or write was input and biba model types and returns true or false if it is appropriate to read or write file
     */
    public static boolean bibamodel(String[] var){
        Main obj = new Main();
        String modelType= obj.getmodel();
        String[] SecurityLevels= {"unclassified","classified","secret","topsecret"};
        String filename = var[1];
        boolean tempchar = filename.contains("_");
        int found = 0;
        int found1 = 0;
        int filesecurity_level = 0;
        int mysecurity_level = 0;
        boolean compar = obj.validSecCom(filename);

        System.out.println(filename);
        if (tempchar == true){
            if (compar == true){
                String[] arrOfStr = filename.split("_");
                for (String a : arrOfStr){
                    for (int i=0; i < SecurityLevels.length; i++){
                        if(a.equals(SecurityLevels[i]))
                        {
                            found++;
                            filesecurity_level =i;
                            break;
                        }
                    }
                }

                for (int i=0; i < SecurityLevels.length; i++){
                    String[] temp = obj.getcredentials(); 
                    if(temp[4].equals(SecurityLevels[i]))
                    {
                        found1++;
                        mysecurity_level =i;
                    }
                }

                if (found1 > 0 && found > 0 ){
                    if (modelType.equals("biba simple")){

                        if (filesecurity_level >= mysecurity_level && var[0].equals("read")){
                            return true;
                        }else if (modelType.equals("biba simple") && var[0].equals("write")){
                            System.out.println("You cant write with the simple confidenttiality rule");
                            return false;
                        }else{
                            return false;
                        } 

                    }else if (modelType.equals("biba strongstar")){

                        if (filesecurity_level == mysecurity_level && var[0].equals("read")){
                            System.out.println("File can be opened");
                            return true;
                        }else if (filesecurity_level == mysecurity_level && var[0].equals("write")){
                            return true;
                        }else{
                            System.out.println("File is out of your security clerence");                            
                            return false;
                        }         

                    }else if (modelType.equals("biba star")){

                        if(modelType.equals("biba star") && var[0].equals("read")){
                            System.out.println("Access denied you can't read files with the star confidenttiality rule");
                            System.out.println("You can only write files at or above your security level");
                            return false;
                        }else if(filesecurity_level <= mysecurity_level && var[0].equals("write")){
                            return true;
                        }else{
                            System.out.println("File is out of your security clerence");
                            return false;
                        } 
                    }
                }else{
                    System.out.println("Security level not found");
                    System.out.println("No security level or improper format of file name.");
                    return false;
                }
            }else{
                System.out.println("File is out of your security clerence");
                System.out.println("File compartment out of clerence.");
                return false;
            }
        }else{
            System.out.println("File has no security level or the file name format is incorrect! ");
            return false;
        }
        return false;
    }

    /**
     *  opens a file and reads it
     */
    public static void openread(String filename){
        try {
            File myObj = new File(filename);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                System.out.println(data);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    /**
     * opens a file and writes to it
     */
    public static void openwrite(String[] var){        
        Main obj = new Main();
        String filename = var[1];
        try{
            BufferedWriter writer = new BufferedWriter(new FileWriter(filename,true));
            writer.append(var[2]);
            writer.newLine();
            writer.close();
            System.out.println("Text Saved to file");

        }catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }   

    /**
     * checks if file exists returns true or false depending on result
     */
    public static boolean validtoopen(String var){
        boolean checkreturned = false;
        File file1 = new File(var);
        if(file1.exists()){
            checkreturned = true;
        }else{
            System.out.println("File doesn't exist. ");
            checkreturned = false;
        }
        return checkreturned;
    }

    /**
     * read Checks the model type biba or blp Types and the rules for that model and reads text from file if it is appropriate. 
     */
    public static void read(String[] var){
        int inlength = var.length;
        Main obj = new Main();

        if (inlength < 2){
            System.out.print("Please try again and indicate the file you wish to read.");

        }else if(obj.getmodel() == null){
            System.out.print("Please log in first");

        }else if(obj.getmodel().equals("biba simple")){
            String filename = var[1];
            boolean openornot = bibamodel(var);
            if (openornot == true){
                openread(filename);
            }

        }else if(obj.getmodel().equals("biba star")){
            String filename = var[1];
            boolean openornot = bibamodel(var);
            if (openornot == true){
                openread(filename);
            }

        }else if(obj.getmodel().equals("biba strongstar")){
            String filename = var[1];
            boolean openornot = bibamodel(var);
            if (openornot == true){
                openread(filename);
            }
        }else if(obj.getmodel().equals("blp simple")){
            String filename = var[1];
            boolean openornot = blpmodel(var);
            if (openornot == true){
                openread(filename);
            }

        }else if(obj.getmodel().equals("blp star")){
            String filename = var[1];
            boolean openornot = blpmodel(var);
            if (openornot == true){
                openread(filename);
            }

        }else if(obj.getmodel().equals("blp strongstar")){
            String filename = var[1];
            boolean openornot = blpmodel(var);
            if (openornot == true){
                openread(filename);
            }

        }else{
            System.out.print("Error Something went wrong");
        }
    }

    /**
     * Creates a user validates if security level and compartment is valid for input. Takes the user information and saves it to the file
     */
    public static void CreateUser(String[] var) throws NoSuchAlgorithmException, NoSuchProviderException   {
        int userInputLength = var.length; 
        String indexZeroCreateUser = var[0];  
        int foundLevel = 0; 
        int  found= 0;         
        String[] SecurityLevels= {"topsecret", "secret", "classified", "unclassified"}; 
        String[] Compartments = {"A","B","A,B"};
        String userprofile;
        Main obj = new Main();

        if (indexZeroCreateUser.isEmpty()){
            System.out.println("User didnt enter anything");

        }else if(userInputLength < 2){ 
            System.out.println("You didn't put the users security level. Please Try again :-)");

        }else if(indexZeroCreateUser.equals("createuser")){

            for (int i=0; i < SecurityLevels.length; i++){
                if(var[1].equals(SecurityLevels[i]))
                {
                    foundLevel++;
                }       
            }

            if(foundLevel > 0){

                for (int i=0; i < Compartments.length; i++){
                    if(userInputLength == 3){
                        if(var[2].equals(Compartments[i]))
                        {
                            foundLevel++;  
                        }

                    }else if(userInputLength == 2){
                        foundLevel++; 
                        break;
                    }
                }

                if(foundLevel == 0){
                    System.out.println("Input compartment not valid"); 

                }else if(foundLevel > 0 || userInputLength == 2){
                    Scanner input = new Scanner(System.in);
                    String username, password, firstname,lastname;

                    System.out.println("Enter users first name: "); 
                    firstname = input.nextLine();

                    System.out.println("Enter users last name: "); 
                    lastname = input.nextLine();

                    System.out.println("Enter users Username: "); 
                    username = input.nextLine();

                    System.out.println("Enter users Password: "); 
                    password = input.nextLine();

                    SaltedMD5 objSaltedMD5Example = new SaltedMD5();
                    String[] Sec = objSaltedMD5Example.getsaltedpassword(password);

                    String saltpass = Sec[0];
                    String salt = Sec[1];

                    if(userInputLength == 2){
                        userprofile = (firstname + ","+ lastname + "," + username + ","+ saltpass +"-"+ salt + "," + var[1]);
                        obj.setProfile(userprofile);
                    }else if(userInputLength >= 3){
                        userprofile = (firstname + ","+ lastname + "," + username + ","+ saltpass +"-"+ salt + "," + var[1] + "," + var[2]);
                        obj.setProfile(userprofile);
                    }else{
                        System.out.println("Something went wrong. Please try again");

                    }

                    try{
                        BufferedWriter writer = new BufferedWriter(new FileWriter("users_topsecret_AB_.txt",true));
                        writer.append(obj.getProfile());
                        writer.newLine();
                        writer.close();
                        if (!obj.getProfile().equals(null)){
                            System.out.println("User Created!");
                        }

                    }catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }

                }else if(foundLevel == 0){
                    System.out.println("Compartment Not Valid!");

                }
            }else if(foundLevel == 0){
                System.out.println("Level Not Valid!");

            }
        }
        return;
    }

    /**
     * Checks user input and splits the user input appropriatly for when write input is used. if input dosnt have write in it then split each word by space and save
     * to array.
     * if includes write split into 3 parts [write,filename,everything else will be stored here so it can be saved in file]
     * 
     */
    public static String[] userinput1(){
        String userinput;
        String[] parts1;
        Scanner input = new Scanner(System.in);        
        System.out.println("\nUser Input: ");
        userinput = input.nextLine();
        boolean tempchar = userinput.contains("write");

        if (tempchar != true){
            parts1 = userinput.split(" ");
        }else{
            parts1 = userinput.split(" ",3);
        }
        input.close();
        return parts1;
    }

    /**
     * prints model types for biba and blp
     */
    public static void modelprompt(){

        String[] model_types ={"biba simple","biba star","biba strongstar","blp simple","blp star","blp strongstar"};
        System.out.println("Model Choices:");
        for (int i=0; i < model_types.length; i++){
            System.out.println(model_types[i]); 
        }

    }

    /**
     * Takes user input checks if user is valid. Then checks input password against encrypted password that is saved. If user valid asks the type of model use wish to use
     * and prints the model types.Saves all info for user session.
     */
    public static String[] login()throws NoSuchAlgorithmException, NoSuchProviderException {
        try {
            Scanner input = new Scanner(System.in);
            String username, password;
            System.out.println("Username: ");
            username = input.nextLine();
            System.out.println("Password: ");
            password = input.nextLine();
            String[] temp;
            String cred;
            Main obj = new Main();
            BufferedReader reader = new BufferedReader(new FileReader("users_topsecret_AB_.txt"));
            String line = reader.readLine();
            SaltedMD5 objSaltedMD5Example = new SaltedMD5();

            while (line != null) {

                temp=line.split(",");
                String t2 = temp[2];
                String t3 = temp[3];
                String[] vartem =t3.split("-");
                String t4 = vartem[0];
                String t5 = vartem[1];

                if (t2.equals(username)){
                    String temppass = objSaltedMD5Example.userloginpassreg(password,t5);
                    if(t4.equals(temppass)){
                        boolean controlloop = false;
                        System.out.println("\nYou are now logged in.");
                        System.out.println("Hello, "+ temp[0]+ "!\n" );
                        obj.setcredentials(temp);

                        while (controlloop != true){
                            modelprompt();
                            System.out.println("Would You like to use the biba model or the BLP model");
                            String modelkind = input.nextLine();
                            String[] model_types ={"biba simple","biba star","biba strongstar","blp simple","blp star","blp strongstar"};
                            int found = 0;

                            for (int i=0; i < model_types.length; i++){
                                if(modelkind.equals(model_types[i]))
                                {
                                    found++;
                                }       
                            }

                            if (found > 0){
                                obj.setmodel(modelkind);
                                controlloop = true;
                            }else{
                                System.out.println("This is not a valid input please try again!!!");
                            }
                        }
                        break;
                    }else{
                        line = reader.readLine();
                    }
                }else{
                    line = reader.readLine();
                }
            }
            if(line == null){
                System.out.println("This user dosen't exist!");           
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }       
        return null;
    }

    /**
     * validates security level input file name and if valid saves file
     */
    public static void createfile(String[] var){
        String[] SecurityLevels= {"topsecret", "secret", "classified", "unclassified"};
        String tt = var[0];
        int found = 0;
        int userInputLength = var.length;
        Main obj = new Main();

        if (tt.isEmpty()){
            System.out.println("User didnt enter anything");
        }

        if(userInputLength == 1 && obj.getcredentials() == null){            
            System.out.print("User didnt enter security level! "); 
        }else if(tt.equals("createfile")){

            String[] varnew = new String[2];
            String[] tem =obj.getcredentials();            
            varnew[0] = var[0];
            varnew[1] = tem[4];

            for (int i=0; i < SecurityLevels.length; i++){
                if(var[1].equals(SecurityLevels[i]))
                {
                    found++;
                }       
            }

            if(found > 0){

                Scanner input = new Scanner(System.in);
                String filename;
                System.out.println("Please input file name you would like to create: ");
                filename = input.nextLine();
                if (userInputLength == 2){

                    filename = (filename +"_"+ varnew[1] +"_"+ ".txt");
                }else if (userInputLength == 3){

                    filename = (filename +"_"+ varnew[1] +"_"+var[2]+"_"+ ".txt");
                }
                try {
                    File myObj = new File(filename);
                    if (myObj.createNewFile()) {
                        System.out.println("File created: " + myObj.getName());
                    } else {
                        System.out.println("File already exists.");
                    }
                } catch (IOException e) {
                    System.out.println("An error occurred.");
                    e.printStackTrace();
                }

            }
            else
            {
                System.out.println("Security level not valid");
            }            
        }
    }

    /**
     * clears user session info 
     */

    public static void logout(){
        Main obj = new Main();
        obj.setcredentials(null);
        obj.setProfile(null);
        obj.setmodel(null);
        System.out.println("User logged out. ");
    }

    /**
     * check user input and executes the appropite method depending on user input
     */
    public static void validinputs(String[] var)throws NoSuchAlgorithmException, NoSuchProviderException{

        String nn = var[0];
        int inputlength = var.length; 
        Main obj = new Main();

        if(nn.isEmpty()){
            System.out.println("Empty input");
        }
        else if (inputlength >= 1){
            switch (var[0]) {
                case "createuser":
                CreateUser(var);                
                break;
                case "login":
                login();
                break;                
                case "createfile":
                createfile(var);
                break;                                
                case "logout":
                logout();                
                break; 
                case "read":
                if (inputlength >= 2){
                    boolean tt = validtoopen(var[1]);
                    if (tt == true){
                        read(var);
                        break;
                    }else{
                        break;
                    }
                }else{
                    System.out.println("Input not valid.");
                    break;
                }
                case "write":
                if (inputlength >= 2){
                    boolean tw = validtoopen(var[1]);
                    if (tw == true){
                        write(var);
                        break;
                    }else{
                        break;
                    }
                }else{
                    System.out.println("Input not valid.");
                    break;

                }
                case "pCred":
                System.out.println(java.util.Arrays.toString(obj.getcredentials()));
                break;

            }
        }
        return;
    }

    /**
     * print all possible user inputs and the appropriate formats
     */
    public static void startProgramPrompt(){

        System.out.println("Program possible enteries: ");
        System.out.println("All enteries must match the examples bellow!");
        System.out.println("Please Log in before using any features");
        System.out.println("\nlogin: This allows login to set credentials");
        System.out.println("login");
        System.out.println("\nlogout: This clears all user credentials");
        System.out.println("logout");
        System.out.println("\nread filename: This opens the file and allows user to read it ");
        System.out.println("read filename");
        System.out.println("\nwrite filename text to write to file: This opens the file if you have the correct credentials so you can write to the file.");
        System.out.println("write filename text here");
        System.out.println("\ncreateuser SecurityLevel (Compartment)Optional: This creates a user ");
        System.out.println("createuser SecurityLevel Compartment");
        System.out.println("createuser SecurityLevel");
        System.out.println("\ncreatefile SecurityLevel (Compartment)Optional: This allows user to create a file at there Security level or above");
        System.out.println("createfile SecurityLevel Compartment");
        System.out.println("createfile SecurityLevel");
        System.out.println("\npCred: This command checks the persons current credentials. ");
        System.out.println("pCred:");
        System.out.println("exitprogram: This command will exit the program");
        System.out.println("exitprogram");

    }

    /**
     * starts program and takes user input validates if input is appropriate
     */
    public static void main(String[] args)throws NoSuchAlgorithmException, NoSuchProviderException {
        Main obj = new Main();
        String varmod;
        startProgramPrompt();

        try{
            do{
                String[] var = obj.userinput1();         
                validinputs(var);           
                varmod = var[0];
            }while (!varmod.equals("exitprogram"));        
            System.out.println("Exit loop!");
        }catch (Exception e){
            System.out.println("Error");

        }

    }
}
