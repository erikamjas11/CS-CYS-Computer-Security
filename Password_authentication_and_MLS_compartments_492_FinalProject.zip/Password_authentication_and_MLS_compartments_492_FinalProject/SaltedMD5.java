import java.security.*;

public class SaltedMD5 
{
    /**
     * Method Takes in password and the previous salt used to encript users password.
     * Returns password passed in Encrypted
     */
    public static String userloginpassreg(String passwordToHash,String saltFromCred)throws NoSuchAlgorithmException, NoSuchProviderException {

        String salt = saltFromCred;
        String securePassword = getSecurePassword(passwordToHash, salt);        
        String regeneratedPassowrdToVerify = getSecurePassword(passwordToHash, salt);        
        String SaltedPassreg = securePassword;

        return SaltedPassreg;    
    }

    /**
     * Takes in password and returns that password encrypted and also returns the salt that was used to encrypt the password. 
     */
    public static String[] getsaltedpassword(String passwordToHash)throws NoSuchAlgorithmException, NoSuchProviderException {
        
        String salt = getSalt();
        String securePassword = getSecurePassword(passwordToHash,salt);
        String regeneratedPassowrdToVerify = getSecurePassword(passwordToHash, salt);
        String[] SaltedPass_salt = {securePassword,salt};

        return SaltedPass_salt;
    }

    /**
     * Takes in password and salt and encypts password and returns a secure password back 
     */
    private static String getSecurePassword(String passwordToHash,String salt)throws NoSuchAlgorithmException, NoSuchProviderException  {

        String generatedPassword = null;
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(salt.getBytes());
            byte[] bytes = md.digest(passwordToHash.getBytes());
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < bytes.length; i++) {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            generatedPassword = sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return generatedPassword;
    }

    
    /**
     * Generates a random salt and returns salt
     */
    private static String getSalt() throws NoSuchAlgorithmException, NoSuchProviderException 
    {
        SecureRandom sr = SecureRandom.getInstance("SHA1PRNG", "SUN");        
        byte[] salt = new byte[16];        
        sr.nextBytes(salt);
        
        return salt.toString();
    }
}