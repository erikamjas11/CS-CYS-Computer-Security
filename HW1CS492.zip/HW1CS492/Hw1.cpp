#include <stdio.h>
#include <stdint.h>

void encrypt (unsigned int val [], unsigned int key []) {
    unsigned int delta = 0x9E3779B9; 
    unsigned int sum = 0;

    for (int i = 0; i < 32; i++) {
        sum += delta;
        
        val [0] += ((val [1] << 4) + key [0]) ^ (val [1] + sum) ^ ((val [1] >> 5) + key [1]);
        val [1] += ((val [0] << 4) + key [2]) ^ (val [0] + sum) ^ ((val [0] >> 5) + key [3]);
    }
}

void decrypt (unsigned int val [], unsigned int key []) {
    unsigned int delta = 0x9E3779B9; 
    unsigned int sum = 32 * delta;
    
    for (int i = 0; i < 32; i++) {   
        
        val [1] -= ((val [0] << 4) + key [2]) ^ (val [0] + sum) ^ ((val [0] >> 5) + key [3]);
        val [0] -= ((val [1] << 4) + key [0]) ^ (val [1] + sum) ^ ((val [1] >> 5) + key [1]);
        sum -= delta;
    }
}

int main(){
    unsigned int plaintxt [] = {0x0FCA4567, 0x0CABCDEF};
    unsigned int key[] = {0xBF6BABCD, 0xEF00F000, 0xFEAFAFAF, 0xACCDEF01};
    
    // Part 1 Use your TEA algorithm to encrypt the 64-bit plaintext block
    encrypt (plaintxt, key);
    printf ("\nEcrypted text: 0x");
    
    for (int i = 0; i < 2; i++){
        printf ("%x", plaintxt[i]);
        
    }
    // Part 2 Implement decryption and verify that you obtain the original plain text
    decrypt (plaintxt, key);
    printf ("\nDecrypted text: 0x");
    
    for (int i = 0; i < 2; i++){
        printf ("%x", plaintxt[i]);
        

    }
    printf ("\n");

    

    return 0;
}

/* Part 3 In comments in your code explain how you would make your code encode/decode 
    a longer set of plaintext (i.e. multiple blocks) using CBC.  You do not need to code this, 
    but your explanation should be detailed related to your implementation.*/

     /* when encoding multiple blocks of plaintext using CBC the blocks should get padded with zeroes if the total
        plaintext length isnt an multiple of 64 bits. When we are encrypting multiple blocks we also need the IV.
        The IV can be the cipher text for the block before it. The IV is then xored with the plaintext
        before the block gets encrypted. */